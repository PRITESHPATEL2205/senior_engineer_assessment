USE PERSONDATABASE

/*********************
Hello! 

Please use the test data provided in the file 'PersonDatabase' to answer the following
questions. Please also import the dbo.Contacts flat file to a table for use. 

All answers should be executable on a MS SQL Server 2012 instance. 

***********************



QUESTION 1

The table dbo.Risk contains calculated risk scores for the population in dbo.Person. Write a 
query or group of queries that return the patient name, and their most recent risk level(s). 
Any patients that dont have a risk level should also be included in the results. 

**********************/

SELECT p.PersonName
      ,r.RiskScore
	  ,r.RiskLevel
FROM person p
OUTER APPLY (SELECT TOP 1 RiskScore,RiskLevel FROM Risk R WHERE R.PersonID=P.PersonID ORDER BY RiskDateTime DESC) r



/**********************

QUESTION 2


The table dbo.Person contains basic demographic information. The source system users 
input nicknames as strings inside parenthesis. Write a query or group of queries to 
return the full name and nickname of each person. The nickname should contain only letters 
or be blank if no nickname exists.

**********************/
 
SELECT p.PersonName
      
	  ,SUBSTRING(p.PersonName
	            ,(charindex('(',p.personname,1)+1)
				,IIF(((charindex(')',p.personname,1)-charindex('(',p.personname,1))-1)<0,0,((charindex(')',p.personname,1)-charindex('(',p.personname,1))-1))
				) AS NickName
	 ,RTRIM(LTRIM(REPLACE(REPLACE(
			   p.PersonName
			  ,SUBSTRING(p.PersonName
						,(charindex('(',p.personname,1))
						,IIF(((charindex(')',p.personname)-charindex('(',p.personname))+1)<0,0,((charindex(')',p.personname)-charindex('(',p.personname))+1))
						) 
	          ,''),')',''))) AS FullName
      ,r.RiskScore
	  ,r.RiskLevel
	  
FROM person p
  OUTER APPLY (SELECT TOP 1 RiskScore,RiskLevel FROM Risk R WHERE R.PersonID=P.PersonID ORDER BY RiskDateTime DESC) r
          


/**********************

QUESTION 6

Write a query to return risk data for all patients, all payers 
and a moving average of risk for that patient and payer in dbo.Risk. 

**********************/
 
SELECT  p.PersonID
       ,p.PersonName       
	   ,AVG(riskscore) over (PARTITION BY r.personid ORDER BY RiskDateTime ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) MovingAverage
  FROM person P
  LEFT JOIN Risk R
          ON P.PersonID = R.PersonID
		  ORDER BY r.PersonID,RiskDateTime

