# -*- coding: utf-8 -*-

import os
import fnmatch
import pandas as pd
import datetime
import pyodbc


pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth',None)

################################
##Connection Management
################################
##File Connection 
path = "C:/Users/ppatel/Desktop/Adhoc Files/Udemy/PriviaAssessment/senior_engineer_assessment-master/PythonTestQuestions"
files = os.listdir(path)
#allnames = pd.DataFrame()

##SQL SERVER Connection
##Trusted Connection, Windows authentication 
sql_conn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=<>;DATABASE=PersonDatabase;Trusted_Connection=yes') 
cur=sql_conn.cursor() 


for f in files:
    if fnmatch.fnmatch(f,'*.xlsx'):
        ################################
        ##extract and format file date
        ##extract group name
        ################################
        groupname = f.replace(f[-11:],'')
        filedate=f[-11:] #extract mmddyyyy.xlsx              
        filedate=filedate.replace('.xlsx', '') #remove .xlsx
        filedate=datetime.datetime.strptime(filedate, "%m%d%y") #convert to date data type
        filedate=datetime.datetime.strftime(filedate, "%m/%d/%Y") #format date to mm/dd/yyyy
        #print (filedate)
        #print (groupname)
        
        ################################
        ##Extract data in a dataframe        
        ################################
        xl=pd.ExcelFile(f)    
        xl_df=xl.parse("Sheet1",header=[3])                

        ################################
        ##Clean & transform
        ################################
        xl_df= xl_df.dropna(axis=1,how='all') 
        xl_df= xl_df.dropna(axis=0,how='all')
        xl_df= xl_df.iloc[:-2]
        xl_df=xl_df.rename(columns=lambda x: x.strip())
        xl_df["Middle Name"].fillna(" ",inplace= True) 
        xl_df["Middle Name"]=xl_df['Middle Name'].astype(str).str[0]
        xl_df["Sex"].replace([0.0,1.0],['M',F''],inplace= True) 
        xl_df["GroupName"]=groupname
        xl_df["FileDate"]=filedate
        
        ################################
        ##Load Data
        ################################
        for row in xl_df.itertuples():
             sql="INSERT INTO [dbo].[GroupRiskData] ([ID] ,[FirstName] ,[MiddleName] ,[LastName] ,[DOB] ,[Sex],[FavouriteColor],[AttributedQA1],[AttributedQA2],[RiskQ1],[RiskQ2] ,[RiskIncreasedFlag],[GroupName],[FileDate] )  VALUES (?  ,?  ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,?,?)"
             cur.execute(sql,row.ID,row._2,row._3,row._4,row._5,row.Sex,row._7,row._8,row._9,row._10,row._11,row._12,row.GroupName,row.FileDate)             
             cur.commit()
        print("File:" + f + " loaded" )
        ################################
        ##Pivot Data Question 2
        ################################
        
        #unpivot attributed table
        xl_df_filtered=xl_df[xl_df['Risk Increased Flag']=='Yes']
        xl_df_attributed= xl_df_filtered[['ID','Attributed Q1','Attributed Q2','FileDate']]        
        xl_df_attributed_upivot=xl_df_attributed.melt(id_vars=['ID','FileDate'], var_name=['Quarter'],value_name='Attributed Flag')
        xl_df_attributed_upivot["Quarter"].replace(to_replace='[Attributed ]',value=' ',inplace=True,regex = True)
        xl_df_attributed_upivot.set_index(['ID','FileDate','Quarter'])

        #unpivot RiskScore table             
        xl_df_RiskScore= xl_df_filtered[['ID','Risk Q1','Risk Q2','FileDate']]        
        xl_df_RiskScore_upivot=xl_df_RiskScore.melt(id_vars=['ID','FileDate'], var_name=['Quarter'],value_name='RiskScore')
        xl_df_RiskScore_upivot["Quarter"].replace(to_replace='[Risk ]',value=' ',inplace=True,regex = True)       
        xl_df_RiskScore_upivot.set_index(['ID','FileDate','Quarter'])
        
        
        xl_df_unpivot_final=xl_df_attributed_upivot.join(xl_df_RiskScore_upivot,lsuffix='_a', rsuffix='_r')[['ID_a','FileDate_a','Quarter_a','RiskScore','Attributed Flag']]  
        print(xl_df_unpivot_final)